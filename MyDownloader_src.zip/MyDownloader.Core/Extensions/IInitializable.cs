using System;
using System.Collections.Generic;
using System.Text;

namespace MyDownloader.Core.Extensions
{
    public interface IInitializable
    {
        void Init();
    }
}
