using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyDownloader.Extension.SpeedLimit.UI
{
    public partial class SetSpeedLimitDialog : Form
    {
        public SetSpeedLimitDialog()
        {
            InitializeComponent();
        }
    }
}