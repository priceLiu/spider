using System;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Specialized;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
/*
This C# file contains:

	Preferences		contains dereferences for the web.config settings

	CatalogBinder	allow the Catalog to be deserialized
	Catalog			contains Hashtable of Words 
	Word			instance of a Word, with a Hashtable of File references
	File			instance of a File, with URL and other attributes
	ResultFile		instance of a File with search ranking (inherits File) used for results only
	
	SpiderProgressEventHandler	used to send crawl progress messages
	ProgressEventArgs	used to send crawl progress messages
	Spider			contains all the intelligence to crawl links, download, parse and index pages
	
	IGoWord			Go words interface + implementation
	IStopper		Stop words interface + implementation
	IStemming		Stemming interface + implementation

*/
#region Url references
/*
http://www.dotnetbips.com/displayarticle.aspx?id=43f
http://www.microbion.co.uk/developers/csharp/dirlist.htm

Stripping HTML
http://www.4guysfromrolla.com/webtech/042501-1.shtml

Opening a file from ASP.NET
http://aspnet.4guysfromrolla.com/articles/051802-1.aspx

Practical parsing in Regular Expressions
http://weblogs.asp.net/rosherove/articles/6946.aspx
*/
#endregion

namespace Searcharoo.Net 
{
	#region Preferences
	/// <summary>
	/// Retrieve data from web.config
	/// </summary>
	public class Preferences
	{
		private Preferences () {}

		private static int IfNullDefault (string appSetting, int defaultValue){
			return System.Configuration.ConfigurationSettings.AppSettings[appSetting] == null?defaultValue:Convert.ToInt32(System.Configuration.ConfigurationSettings.AppSettings[appSetting]);
		}
		private static string IfNullDefault (string appSetting, string defaultValue) 
		{
			return System.Configuration.ConfigurationSettings.AppSettings[appSetting] == null?defaultValue:System.Configuration.ConfigurationSettings.AppSettings[appSetting];
		}
		private static bool IfNullDefault (string appSetting, bool defaultValue) 
		{
			return System.Configuration.ConfigurationSettings.AppSettings[appSetting] == null?defaultValue:Convert.ToBoolean(System.Configuration.ConfigurationSettings.AppSettings[appSetting]);
		}
		/// <summary>
		/// Seconds to wait for a page to respond, before giving up. 
		/// Default: 5 seconds
		/// </summary>
		public static int RequestTimeout 
		{
			get 
			{
				return IfNullDefault("Searcharoo_RequestTimeout", 5);
			}
		}
		
		/// <summary>
		/// First page to search - should have LOTS of links to follow
		/// Default: http://localhost/
		/// </summary>
		public static string StartPage 
		{
			get 
			{
				return IfNullDefault("Searcharoo_VirtualRoot", @"http://localhost/");
			}
		}
		
		/// <summary>
		/// Limit to the number of 'levels' of links to follow
		/// Default: 200 
		/// </summary>
		public static int RecursionLimit 
		{
			get 
			{
				return IfNullDefault("Searcharoo_RecursionLimit", 200);
			}
		}
		
		/// <summary>
		/// Request another page after waiting x seconds; use zero ONLY on your own/internal sites
		/// Default: 1 
		/// </summary>
		public static int SpeedLimit 
		{
			get 
			{
				return IfNullDefault("Searcharoo_SpeedLimit", 1);
			}
		}
		
		/// <summary>
		/// Whether to use stemming (English only), and if so, what mode [ Off | StemOnly | StemAndOriginal ]
		/// Default: Off
		/// </summary>
		public static int StemmingMode 
		{
			get 
			{
				return IfNullDefault("Searcharoo_StemmingType", 0);
			}
		}

		/// <summary>
		/// Whether to use stemming (English only), and if so, what mode [ Off | Short | List ]
		/// Default: Off
		/// </summary>
		public static int StoppingMode 
		{
			get 
			{
				return IfNullDefault("Searcharoo_StoppingType", 0);
			}
		}
		/// <summary>
		/// Whether to use go words (English only), and if so, what mode [ Off | On ]
		/// Default: Off
		/// </summary>
		public static int GoWordMode 
		{
			get 
			{
				return IfNullDefault("Searcharoo_GoType", 0);
			}
		}

		/// <summary>
		/// Number of characters to include in 'file summary'
		/// Default: 350
		/// </summary>
		public static int SummaryCharacters 
		{
			get 
			{
				return IfNullDefault("Searcharoo_SummaryChars", 350);
			}
		}
		
		/// <summary>
		/// User Agent sent with page requests, in case you wish to change it
		/// Default: Mozilla/6.0 (MSIE 6.0; Windows NT 5.1; Searcharoo.NET; robot)
		/// </summary>
		public static string UserAgent 
		{
			get 
			{
				return IfNullDefault("Searcharoo_UserAgent", "Mozilla/6.0 (MSIE 6.0; Windows NT 5.1; Searcharoo.NET; robot)");
			}
		}
		
		/// <summary>
		/// Application[] cache key where the Catalog is stored, in case you need to alter it
		/// Default: Searcharoo_Catalog
		/// </summary>
		public static string CatalogCacheKey 
		{
			get 
			{
				return IfNullDefault("Searcharoo_CacheKey", "Searcharoo_Catalog");
			}
		}
		
		/// <summary>
		/// Name of file where the Catalog object is serialized (.dat and .xml)
		/// Default: searcharoo
		/// </summary>
		public static string CatalogFileName
		{
			get 
			{
				string location = System.Web.HttpContext.Current.Server.MapPath ("/");
				return location + IfNullDefault("Searcharoo_CatalogFilename", "searcharoo");
			}
		}

		/// <summary>
		/// Number of result links to include per page
		/// Default: 10
		/// </summary>
		public static int ResultsPerPage
		{
			get 
			{
				return IfNullDefault("Searcharoo_DefaultResultsPerPage", 10);
			}
		}

		/// <summary>
		/// Language to use when none is supplied (or supplied language is not available)
		/// Default: en-US
		/// </summary>
		public static string DefaultLanguage
		{
			get 
			{
				return IfNullDefault("Searcharoo_DefaultLanguage", "en-US");
			}
		}

		/// <summary>
		/// Whether to create the Xml Serialized Catalog (for debugging purposes).
		/// The filesize tends to be quite large (DOUBLE the source data size) so
		/// it is FALSE by default.
		/// Default: false
		/// </summary>
		public static bool DebugSerializeXml
		{
			get 
			{
				return IfNullDefault("Searcharoo_DebugSerializeXml", false);
			}
		}
	}  // Preferences class
	#endregion

	#region Catalog
	/// <summary>
	/// Required by Binary Deserializer
	/// </summary>
	/// <remarks>
	/// .NET XML and SOAP Serialization Samples, Tips (goxman)
	/// http://www.codeproject.com/soap/Serialization_Samples.asp
	/// 
	/// It's a long story, but basically if you DON'T provide this information
	/// the deserializer gets very confused if the code is recompiled and therefore
	/// has a different 'Type(version)'. See the Catalog.Save() method for it's use.
	/// </remarks>
	public class CatalogBinder: System.Runtime.Serialization.SerializationBinder
	{
		public override Type BindToType (string assemblyName, string typeName) 
		{ 
			// get the 'fully qualified (ie inc namespace) type name' into an array
			string[] typeInfo = typeName.Split('.');
			// because the last item is the class name, which we're going to 'look for'
			// in *this* namespace/assembly
			string className=typeInfo[typeInfo.Length -1];
			if (className.Equals("Catalog"))
			{
				return typeof (Catalog);
			}
			else if (className.Equals("Word"))
			{
				return typeof (Word);
			}
			if (className.Equals("File"))
			{
				return typeof (File);
			}
			else
			{	// pass back exactly what was passed in!
				return Type.GetType(string.Format( "{0}, {1}", typeName, assemblyName));
			}
		} 
	}

	/// <summary>
	/// Catalog of Words (and Files)
	/// <summary>
	/// <remarks>
	/// XmlInclude
	/// http://pluralsight.com/blogs/craig/archive/2004/07/08/1580.aspx
	/// </remarks>
	[Serializable]
	[System.Xml.Serialization.XmlInclude(typeof(Searcharoo.Net.Word))]
	public class Catalog 
	{
		/// <summary>
		/// Internal datastore of Words referencing Files
		/// </summary>
		/// <remarks>
		/// Hashtable
		/// key    = STRING representation of the word, 
		/// value  = Word OBJECT (with File collection, etc)
		/// </remarks>
		private System.Collections.Hashtable index;	//TODO: implement collection with faster searching

		/// <summary>
		/// Words in the Catalog
		/// </summary>
		/// <remarks>
		/// Added property to allow Serialization to disk
		/// NOTE: the XmlInclude attribute on the Catalog class, which is what
		/// enables this array of 'non-standard' objects to be serialized correctly
		/// </remarks>
		[XmlElement("words")]
		public Word[] Words
		{
			get 
			{
				Word[] wordArray = new Word[index.Count];
				index.Values.CopyTo (wordArray, 0);
				return wordArray;
			}
			set 
			{	
				Word[] wordArray = value;
				index = new Hashtable();
			}
		}

		/// <summary>
		/// String array representing the list of words. 
		/// Used mainly for debugging - ie in the Save() method - so you can 
		/// see what the Spider found.
		/// </summary>
		[XmlAttribute("dict")]
		public string[] Dictionary
		{
			get 
			{
				string[] wordArray = new string[index.Count];
				index.Keys.CopyTo (wordArray, 0);
				return wordArray;
			}
		}
		/// <summary>
		/// Number of Words in the Catalog
		/// </summary>
		public int Length 
		{
			get {return index.Count;}
		}

		/// <summary>
		/// Constructor - creates the Hashtable for internal data storage.
		/// </summary>
		public Catalog () 
		{
			index = new System.Collections.Hashtable ();
		}
		/// <summary>
		/// Add a new Word/File pair to the Catalog
		/// </summary>
		public bool Add (string word, File infile, int position)
		{
			// ### Make sure the Word object is in the index ONCE only
			if (index.ContainsKey (word) ) 
			{
				Word theword = (Word)index[word];	// add this file reference to the Word
				theword.Add(infile, position);
			}
			else 
			{
				Word theword = new Word(word, infile, position);	// create a new Word object
				index.Add(word, theword);
			}
			return true;
		}
		/// <summary>
		/// Returns all the Files which contain the searchWord
		/// </summary>
		/// <returns>
		/// Hashtable where:
		/// </returns>
		public Hashtable Search (string searchWord)
		{
			// apply the same 'trim' as when we're building the catalog
			//searchWord = searchWord.Trim(' ','?','\"',',','\'',';',':','.','(', ')','[',']','%','*','$','-').ToLower();
			Hashtable retval = null;
			if (index.ContainsKey (searchWord) ) 
			{	// does all the work !!!
				Word thematch = (Word)index[searchWord];
				retval = thematch.InFiles(); // return the collection of File objects
			}
			return retval;
		}
	
		/// <summary>
		/// Debug string
		/// </summary>
		public override string ToString()
		{
			string wordlist="";
			//foreach (object w in index.Keys) temp += ((Word)w).ToString();	// output ALL words, will take a long time
			return "\nCATALOG :: " + index.Values.Count.ToString() + " words.\n" + wordlist;
		}

		/// <summary>
		/// Save the catalog to disk by BINARY serializing the object graph as a *.DAT file.
		/// </summary>
		/// <remarks>
		/// For 'reference', the method also saves XmlSerialized copies of the Catalog (which
		/// can get quite large) and just the list of Words that were found. In production, you
		/// would probably comment out/remove the Debugging code.
		/// 
		/// You may also wish to use a difficult-to-guess filename for the serialized data, 
		/// or else change the .DAT file extension to something that will be not be served by
		/// IIS (so that other people can't download your catalog).
		/// </remarks>
		public void Save ()
		{
			// BINARY http://www.dotnetspider.com/technology/kbpages/454.aspx
			System.IO.Stream stream = new System.IO.FileStream( Preferences.CatalogFileName+".dat" , System.IO.FileMode.Create );
			System.Runtime.Serialization.IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			formatter.Serialize ( stream, this );
			stream.Close();
		
			#region Debugging Serialization - these are only really useful for looking at; they're not re-loaded
			if (Preferences.DebugSerializeXml)
			{
				//#if DEBUG
				// TODO: Maybe use to save as ZIP - save space on disk? http://www.123aspx.com/redir.aspx?res=31602
				// XML http://www.devhood.com/Tutorials/tutorial_details.aspx?tutorial_id=236
				XmlSerializer serializerXml = new XmlSerializer( typeof( Catalog ) );
				System.IO.TextWriter writer = new System.IO.StreamWriter( Preferences.CatalogFileName+".xml" );
				serializerXml.Serialize( writer, this );
				writer.Close();

				// XML http://www.devhood.com/Tutorials/tutorial_details.aspx?tutorial_id=236
				XmlSerializer serializerXmlW = new XmlSerializer( typeof( string[] ) );
				System.IO.TextWriter writerW = new System.IO.StreamWriter( Preferences.CatalogFileName+"_words.xml" );
				serializerXmlW.Serialize( writerW, this.Dictionary );
				writerW.Close();
				//#endif
			}
			#endregion
		}

		/// <summary>
		/// 
		/// </summary>
		/// <returns>the catalog deserialized from disk, or NULL</returns>
		public static Catalog Load ()
		{
			//if (System.IO.File.Exists (Server.MapPath(Preferences.CatalogFileName+".dat")))
			if (System.IO.File.Exists (Preferences.CatalogFileName+".dat"))
			{
				System.IO.Stream stream = new System.IO.FileStream(Preferences.CatalogFileName+".dat", System.IO.FileMode.Open );
				System.Runtime.Serialization.IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
				//object m = formatter.Deserialize (stream); // This doesn't work, SerializationException "Cannot find the assembly <random name>"
				formatter.Binder = new CatalogBinder();	// This custom Binder is REQUIRED to find the classes in our current 'Temporary ASP.NET Files' assembly
				object m = formatter.Deserialize (stream);
				stream.Close();
				Catalog catalog = m as Catalog;
				
				return catalog;
			}
			else
			{
				return null;
			}
		}
	}
	#endregion

	#region Word
	/// <summary>Instance of a word<summary>
	[Serializable]
	public class Word 
	{
		/// <summary>
		/// Collection of files the word appears in
		/// </summary>
		private System.Collections.Hashtable fileCollection = new System.Collections.Hashtable ();

		/// <summary>
		/// The cataloged word
		/// </summary>
		[XmlElement("t")]
		public string Text;

		/// <summary>
		/// Files that this Word appears in
		/// </summary>
		[XmlElement("fs")]
		public File[] Files
		{
			get 
			{
				File[] fileArray = new File[fileCollection.Count];
				fileCollection.Keys.CopyTo (fileArray, 0);
				return fileArray;
			}
			set 
			{	
				File[] fileArray = value;
				Hashtable index = new Hashtable();
			}
		}

		/// <summary>
		/// Required for serialization
		/// </summary>
		public Word () {}
	
		/// <summary>Constructor with first file reference</summary>
		public Word (string text, File infile, int position)
		{
			Text = text;
			//WordInFile thefile = new WordInFile(filename, position);
			fileCollection.Add (infile, 1);
		}
	
		/// <summary>Add a file referencing this word</summary>
		public void Add (File infile, int position)
		{
			if (fileCollection.ContainsKey (infile)) 
			{
				int wordcount = (int)fileCollection[infile];
				fileCollection[infile] = wordcount + 1 ; //thefile.Add (position);
			} 
			else 
			{
				//WordInFile thefile = new WordInFile(filename, position);
				fileCollection.Add (infile, 1);
			}
		}
	
		/// <summary>Collection of files containing this Word (Value=WordCount)</summary>
		public Hashtable InFiles ()
		{
			return fileCollection;
		}
	
		/// <summary>Debug string</summary>
		public override string ToString()
		{
			string temp="";
			foreach (object tempFile in fileCollection.Values) temp += ((File)tempFile).ToString();
			return "\tWORD :: " + Text + "\n\t\t" + temp + "\n";
		}
	}
	#endregion

	#region File
	/// <summary>
	/// File attributes
	/// </summary>
	/// <remarks>
	/// *Beware* ambiguity with System.IO.File - always fully qualify File object references
	/// </remarks>
	[Serializable]
	public class File
	{
		#region Fields - can't remember why these were made public!
		[XmlIgnore]
		public string _Url;
		[XmlIgnore] 
		public string _Title;
		[XmlIgnore] 
		public string _Description;
		[XmlIgnore] 
		public DateTime _CrawledDate;
		[XmlIgnore] 
		public long   _Size;
		#endregion

		[XmlAttribute("u")]
		public string Url 
		{
			get {return _Url;}
			set {_Url = value;}
		}
		[XmlAttribute("t")]
		public string Title {
			get {return _Title;}
			set {_Title = value;}
		}
		[XmlElement("d")]
		public string Description {
			get {return _Description;}
			set {_Description = value;}
		}
		[XmlAttribute("d")]
		public DateTime CrawledDate {
			get {return _CrawledDate;}
			set {_CrawledDate = value;}
		}
		[XmlAttribute("s")]
		public long  Size {
			get {return _Size;}
			set {_Size = value;}
		}
		/// <summary>
		/// Required for serialization
		/// </summary>
		public File () {}

		/// <summary>
		/// Constructor requires all File attributes
		/// </summary>
		public File (string url, string title, string description, DateTime datecrawl, long length)
		{
			_Title       = title;
			_Description = description;
			_CrawledDate = datecrawl;
			_Url         = url;
			_Size        = length;
		}

		/// <summary>
		/// Debug string
		/// </summary>
		public override string ToString()
		{
			return "\tFILE :: " + Url + " -- " + Title + " - " + Size + " bytes + \n\t" + Description + "\n";
		}
	} 
	/// <summary>
	/// 
	/// </summary>
	public class ResultFile : File
	{
		private int _Rank;
		public ResultFile (File sourceFile)
		{
			this.Url		= sourceFile.Url;
			this.Title		= sourceFile.Title;
			this.Description = sourceFile.Description;
			this.CrawledDate = sourceFile.CrawledDate;
			this.Size		= sourceFile.Size;
			this.Rank		= -1;
		}
		public int Rank
		{
			get{return _Rank;}
			set{_Rank = value;}
		}
	}
	#endregion

	#region Spider (including ProgressEvent stuff)
	// Declaring the Event Handler delegate
	public delegate void SpiderProgressEventHandler (object source, ProgressEventArgs ea);
	// Declare the Event arguments
	public class ProgressEventArgs : EventArgs
	{
		private int _level = 0;
		private string _message = null;

		public ProgressEventArgs (int level, string message)
		{
			this._level = level;
			this._message = message;
		}

		public int Level
		{
			get { return this._level; }
		}

		public string Message
		{
			get { return this._message; }
		}
	}

	/// <summary>
	/// The Spider that crawls your website, link by link.
	/// </summary>
	/// <remarks>
	/// In the version of Searcharoo with spidering (v2), this code was 'embedded'
	/// in an ASPX page. This was for ease of reporting 'progress' via Response.Write
	/// statements. The code now uses an EventHandler to trigger progress reporting
	/// by the calling code - so now it could be Reponse.Write, or saved to a file 
	/// or any other mechanism (could also handle the different 'levels' of message
	/// differently).
	/// 
	/// Some of the references used when researching this page:
	///
	/// C# and the Web: Writing a Web Client Application with Managed Code in the Microsoft .NET Framework - not helpful...
	/// http://msdn.microsoft.com/msdnmag/issues/01/09/cweb/default.aspx
	///
	/// Retrieving a List of Links & Images from a Web Page
	/// http://www.dotnetjunkies.com/Tutorial/1B219C93-7702-4ADF-9106-DFFDF90914CF.dcik
	/// 
	/// FUTURE: In case connecting via a Proxy is required for the spidering
	/// http://www.experts-exchange.com/Programming/Programming_Languages/Dot_Net/Q_20974147.html
	/// http://msdn.microsoft.com/library/en-us/cpref/html/frlrfsystemnetglobalproxyselectionclasstopic.asp
	/// </remarks>
	public class Spider 
	{
		/// <summary></summary>
		protected ArrayList visited = new ArrayList();
		/// <summary></summary>
		protected Hashtable visitedH = new Hashtable();
		/// <summary></summary>
		protected int count=0;
		/// <summary></summary>
		protected Catalog m_catalog ;
		/// <summary></summary>
		private bool PrintDebug = false;
    
		/// <summary>Stemmer to use</summary>
		private IStemming Stemmer;
    
		/// <summary>Stemmer to use</summary>
		private IStopper Stopper;

		/// <summary>Go word parser to use</summary>
		private IGoWord GoChecker;
    
		/// <summary>SIMONJONES</summary>
		System.Net.CookieContainer _ccContainer = new System.Net.CookieContainer();

		/// <summary>
		/// Event Handler to communicate progress and errors back to the calling code
		/// </summary>
		/// <remarks>
		/// Learned about Events from a few places
		/// http://www.codeproject.com/csharp/csevents01.asp
		/// http://www.csharphelp.com/archives/archive253.html
		/// http://www.devhood.com/Tutorials/tutorial_details.aspx?tutorial_id=380
		/// </remarks>
		public event SpiderProgressEventHandler SpiderProgressEvent;

		/// <summary>
		/// Only trigger the event if a Handler has been attached.
		/// </summary>
		private void ProgressEvent (object sender, ProgressEventArgs pea) {
			if (this.SpiderProgressEvent != null)
			{
				SpiderProgressEvent(sender, pea);
			}
		}

		/// <summary>
		/// Takes a single Uri (Url) and returns the catalog that is generated
		/// by following all the links from that point.
		/// </summary>
		/// <remarks>
		///
		/// </remarks>
		public Catalog BuildCatalog (Uri startPageUri)
		{
			m_catalog = new Catalog();

			switch (Preferences.StemmingMode)
			{
				case 1:
					ProgressEvent (this, new ProgressEventArgs(1, "Stemming enabled.") );
					Stemmer = new PorterStemmer();	//Stemmer = new SnowStemming();
					break;
				case 2:
					ProgressEvent (this, new ProgressEventArgs(1, "Stemming enabled.") );
					Stemmer = new PorterStemmer();
					break;
				default:
					ProgressEvent (this, new ProgressEventArgs(1, "Stemming DISabled.") );
					Stemmer = new NoStemming();
					break;
			}
			switch (Preferences.StoppingMode)
			{
				case 1:
					ProgressEvent (this, new ProgressEventArgs(1, "Stop words shorter than 3 chars.") );
					Stopper = new ShortStopper();
					break;
				case 2:
					ProgressEvent (this, new ProgressEventArgs(1, "Stop words from list.") );
					Stopper = new ListStopper();
					break;
				default:
					ProgressEvent (this, new ProgressEventArgs(1, "Stopping DISabled.") );
					Stopper = new NoStopping();
					break;
			}
			switch (Preferences.GoWordMode)
			{
				case 1:
					ProgressEvent (this, new ProgressEventArgs(1, "Go Words enabled.") );
					GoChecker = new ListGoWord();
					break;
				default:
					ProgressEvent (this, new ProgressEventArgs(1, "Go Words DISabled.") );
					GoChecker = new NoGoWord();
					break;
			}

			// GETS THE FIRST DOCUMENT, AND STARTS THE SPIDER! -- create the 'root' document to start the search
			HtmlDocument htmldoc = new HtmlDocument (startPageUri);
			// RECURSIVE CALL TO 'Process()' STARTS HERE
			Process (htmldoc);

			// Now we've FINISHED Spidering
			ProgressEvent (this, new ProgressEventArgs(1,
				"Spider.Catalog() complete. Attempting to serialize to disk location " + Preferences.CatalogFileName) );

			// Serialization of the Catalog, so we can load it again if the server Application is restarted
			m_catalog.Save();

			return m_catalog;// finished, return to the calling code to 'use'
		}


		/// <summary>
		///
		/// </summary>
		/// <remarks>
		///
		/// </remarks>
		protected void Process (HtmlDocument htmldoc)
		{
			string filedesc="";
			long   filesize =0;
			int wordcount=0;
			if (htmldoc == null) ProgressEvent (this, new ProgressEventArgs(3,"00"));
			if (htmldoc.Uri == null) ProgressEvent (this, new ProgressEventArgs(3,"AA"));
			if (htmldoc.Uri.AbsoluteUri == null) ProgressEvent (this, new ProgressEventArgs(3,"BB"));
			string url = htmldoc.Uri.AbsoluteUri;

			if (count > Preferences.RecursionLimit) return;

			if (visited.Contains (url))
			{
				ProgressEvent (this, new ProgressEventArgs(2,"<font size=-2>&nbsp;&nbsp;"+ url +" already spidered</font>"));
			}
			else
			{
				count++;
				visited.Add (url);
				ProgressEvent (this, new ProgressEventArgs(2,"<font size=1>" + url + "</font>"));
				if (Download (htmldoc) )
				{
					Parse (htmldoc);	// have to parse first, to determine Robot metas, etc
					if (htmldoc.RobotIndexOK)
					{
						wordcount = Catalog(htmldoc);
					} 
					else 
					{
						ProgressEvent (this, new ProgressEventArgs(2,"<p style='color:red'>Robot exclusion prevented indexing of " + url + "</p>&nbsp;&nbsp;&nbsp;&nbsp;<font size=2>"));
					}
				}
				else
				{
					ProgressEvent (this, new ProgressEventArgs(1,"<p style='color:red'>Download() failed on " + url + "</p>&nbsp;&nbsp;&nbsp;&nbsp;<font size=2>"));
				}
				if (PrintDebug) 
				{
					ProgressEvent (this, new ProgressEventArgs(2,"<p><b>" + htmldoc.Title + "</b>&nbsp;&nbsp;&nbsp;&nbsp;<font size=2>"
						+ htmldoc.Url + "</font>"
						+ (PrintDebug?htmldoc.Description:"")
						+ " parsed " + wordcount + " words! <font color=red>"
						+ (htmldoc.RobotIndexOK?"Indexed":"Robot Excluded Index") +"</font>") 
					);
				}
				else
				{
					if (wordcount>0) ProgressEvent (this, new ProgressEventArgs(1,"<b>" + htmldoc.Title + "</b> parsed " + wordcount + " words!") );
				}
			
				// ### Loop through the 'local' links in the document ###
				// ### and parse each of them recursively ###
				if (null != htmldoc.LocalLinks && htmldoc.RobotFollowOK)
				{ // only if the Robot meta says it's OK
					foreach (object link in htmldoc.LocalLinks)
					{
						try
						{
							Uri a = new Uri (htmldoc.Uri, link.ToString());
							HtmlDocument hd = new HtmlDocument (a);
							Process (hd);
						}
						catch (Exception ex)
						{
							ProgressEvent (this, new ProgressEventArgs(2,"<font color=red>new Uri("+htmldoc.Uri + ", "+link.ToString()+") invalid : " +  ex.Message + "</font>"));
						}
					}
				} // process local links
			} // not visited
		} // Process


		/// <summary>
		/// http://www.123aspx.com/redir.aspx?res=28320
		/// </summary>
		/// <remarks>
		///
		/// </remarks>
		protected bool Download (HtmlDocument htmldoc)
		{
			bool success				= false;
			// Open the requested URL
			System.Net.HttpWebRequest req	= (System.Net.HttpWebRequest) System.Net.WebRequest.Create(htmldoc.Uri.AbsoluteUri);
			req.AllowAutoRedirect		= true;
			req.MaximumAutomaticRedirections = 3;
			req.UserAgent				= Preferences.UserAgent; //"Mozilla/6.0 (MSIE 6.0; Windows NT 5.1; Searcharoo.NET)";
			req.KeepAlive				= true;
			req.Timeout					= Preferences.RequestTimeout * 1000; //prefRequestTimeout 
        
			// SIMONJONES http://codeproject.com/aspnet/spideroo.asp?msg=1421158#xx1421158xx
			req.CookieContainer = new System.Net.CookieContainer();
			req.CookieContainer.Add(_ccContainer.GetCookies(htmldoc.Uri));

			// Get the stream from the returned web response
			System.Net.HttpWebResponse webresponse = null;
			try
			{
				webresponse = (System.Net.HttpWebResponse) req.GetResponse();
			}
			catch (System.Net.WebException we)
			{
				//remote url not found, 404
				//remote url forbidden, 403
				ProgressEvent (this, new ProgressEventArgs(2,"<font color=red>skipped  " + htmldoc.Uri + " response exception:" + we.ToString() + "</font>") );
			}
        
			if (webresponse != null)
			{
				/* SIMONJONES */
				/* **************** this doesn't necessarily work yet...
				if (webresponse.ResponseUri != htmldoc.Uri)
				{	// we've been redirected, 
					if (visited.Contains(webresponse.ResponseUri.ToString().ToLower()))
					{
						return true;
					}
					else
					{
						visited.Add(webresponse.ResponseUri.ToString().ToLower());
					}
				}*/
			
				try 
				{
					webresponse.Cookies = req.CookieContainer.GetCookies(req.RequestUri);
					// handle cookies (need to do this incase we have any session cookies)
					foreach (System.Net.Cookie retCookie in webresponse.Cookies)
					{
						bool cookieFound = false;
						foreach (System.Net.Cookie oldCookie in _ccContainer.GetCookies(htmldoc.Uri))
						{
							if (retCookie.Name.Equals(oldCookie.Name))
							{
								oldCookie.Value = retCookie.Value;
								cookieFound = true;
							}
						}
						if (!cookieFound)
						{
							_ccContainer.Add(retCookie);
						}
					} 
				}
				catch  (Exception ex)
				{
					ProgressEvent (this, new ProgressEventArgs(2,"<font color=red> cookie processing error : " +  ex.Message + "</font>") );
				}
				/* end SIMONJONES */
			
				htmldoc.ContentType = webresponse.ContentType; // Parse out MimeType and Charset
				switch (htmldoc.MimeType.ToLower() )
				{
					case "text/css":
						// do not process CSS for now...
						break;
					default:
						if (htmldoc.MimeType.IndexOf("text") >= 0)
						{    // If we got 'text' data (not images)
							string enc = "utf-8"; // default
							if (webresponse.ContentEncoding != String.Empty)
							{
								// Use the HttpHeader Content-Type in preference to the one set in META
								htmldoc.Encoding = webresponse.ContentEncoding;
							}
							else if (htmldoc.Encoding == String.Empty) 
							{
								// TODO: if still no encoding determined, try to readline the stream until we find either
								// * META Content-Type or * </head> (ie. stop looking for META)
								htmldoc.Encoding = enc; // default
							}
							//http://www.c-sharpcorner.com/Code/2003/Dec/ReadingWebPageSources.asp
							System.IO.StreamReader stream = new System.IO.StreamReader
								(webresponse.GetResponseStream(), Encoding.GetEncoding(htmldoc.Encoding) );

							htmldoc.Uri = webresponse.ResponseUri; // we *may* have been redirected... and we want the *final* URL
							htmldoc.Length = webresponse.ContentLength;
							htmldoc.All = stream.ReadToEnd ();
							stream.Close();
							success = true;
						}
						else
						{
							ProgressEvent (this, new ProgressEventArgs(2,"<font color=red>skipped mime type: "+htmldoc.MimeType+" for " + htmldoc.Uri + "</font>") );
						}
						break;
				} // switch
				webresponse.Close();
			}
			else 
			{
				ProgressEvent (this, new ProgressEventArgs(2,"<font color=red>no WebResponse for "+ htmldoc.Uri  +"</font>") );
				success = false;
			}
			return success;
		}



		/// <summary>
		///
		/// </summary>
		/// <remarks>
		///
		/// "Original" link search Regex used by the code was from here
		/// http://www.dotnetjunkies.com/Tutorial/1B219C93-7702-4ADF-9106-DFFDF90914CF.dcik
		/// but it was not sophisticated enough to match all tag permutations
		///
		/// whereas the Regex on this blog will parse ALL attributes from within tags...
		/// IMPORTANT when they're out of order, spaced out or over multiple lines
		/// http://blogs.worldnomads.com.au/matthewb/archive/2003/10/24/158.aspx
		/// http://blogs.worldnomads.com.au/matthewb/archive/2004/04/06/215.aspx
		///
		/// http://www.experts-exchange.com/Programming/Programming_Languages/C_Sharp/Q_20848043.html
		/// </remarks>
		protected void Parse ( HtmlDocument pmd )
		{
			string   htmlData = pmd.All;	// htmlData will be munged
			pmd.Html          = pmd.All;	// keep this for 'reference'
		
			//xenomouse http://www.codeproject.com/aspnet/Spideroo.asp?msg=1271902#xx1271902xx
			pmd.Title = Regex.Match (htmlData, @"(?<=<title[^\>]*>).*?(?=</title>)",
				RegexOptions.IgnoreCase|RegexOptions.ExplicitCapture).Value;


			string metaKey = String.Empty, metaValue = String.Empty;
			foreach (Match metamatch in Regex.Matches (htmlData
				, @"<meta\s*(?:(?:\b(\w|-)+\b\s*(?:=\s*(?:""[^""]*""|'[^']*'|[^""'<> ]+)\s*)?)*)/?\s*>"
				, RegexOptions.IgnoreCase|RegexOptions.ExplicitCapture))
			{
				metaKey = String.Empty;
				metaValue = String.Empty;
				// Loop through the attribute/value pairs inside the tag
				foreach (Match submetamatch in Regex.Matches(metamatch.Value.ToString()
					, @"(?<name>\b(\w|-)+\b)\s*=\s*(""(?<value>[^""]*)""|'(?<value>[^']*)'|(?<value>[^""'<> ]+)\s*)+"
					, RegexOptions.IgnoreCase|RegexOptions.ExplicitCapture))
				{

					if ("http-equiv" == submetamatch.Groups[1].ToString().ToLower() )
					{
						metaKey = submetamatch.Groups[2].ToString();
					}
					if ( ("name" == submetamatch.Groups[1].ToString().ToLower() )
						&& (metaKey == String.Empty) )
					{ // if it's already set, HTTP-EQUIV takes precedence
						metaKey = submetamatch.Groups[2].ToString();
					}
					if ("content" == submetamatch.Groups[1].ToString().ToLower() )
					{
						metaValue = submetamatch.Groups[2].ToString();
					}
				}
				ProgressEvent (this, new ProgressEventArgs (3,metaKey + " " + metaValue));
				switch (metaKey.ToLower())
				{
					case "description":
						pmd.Description = metaValue;
						break;
					case "keywords":
					case "keyword":
						pmd.Keywords = metaValue;
						break;
					case "robots":
					case "robot":
						pmd.SetRobotDirective (metaValue);
						break;
				}
				ProgressEvent (this, new ProgressEventArgs (3, metaKey + " = " +  metaValue));
			}

			string link=String.Empty;

			ArrayList linkLocal    = new ArrayList();
			ArrayList linkExternal = new ArrayList();

			// http://msdn.microsoft.com/library/en-us/script56/html/js56jsgrpregexpsyntax.asp
			// Original Regex, just found <a href=""> links; and was "broken" by spaces, out-of-order, etc
			// @"(?<=<a\s+href="").*?(?=""\s*/?>)"
			// Looks for the src attribute of:
			// <A> anchor tags
			// <AREA> imagemap links
			// <FRAME> frameset links
			// <IFRAME> floating frames
			foreach (Match match in Regex.Matches(htmlData
				, @"(?<anchor><\s*(a|area|frame|iframe)\s*(?:(?:\b\w+\b\s*(?:=\s*(?:""[^""]*""|'[^']*'|[^""'<> ]+)\s*)?)*)?\s*>)"
				, RegexOptions.IgnoreCase|RegexOptions.ExplicitCapture))
			{
				// Parse ALL attributes from within tags... IMPORTANT when they're out of order!!
				// in addition to the 'href' attribute, there might also be 'alt', 'class', 'style', 'area', etc...
				// there might also be 'spaces' between the attributes and they may be ", ', or unquoted
				link=String.Empty;
				ProgressEvent (this, new ProgressEventArgs(3,"<font color=green>"+ System.Web.HttpUtility.HtmlEncode(match.Value) + "</font>"));
				foreach (Match submatch in Regex.Matches(match.Value.ToString()
					, @"(?<name>\b\w+\b)\s*=\s*(""(?<value>[^""]*)""|'(?<value>[^']*)'|(?<value>[^""'<> \s]+)\s*)+"
					, RegexOptions.IgnoreCase|RegexOptions.ExplicitCapture))
				{
					// we're only interested in the href attribute (although in future maybe index the 'alt'/'title'?)
					ProgressEvent (this, new ProgressEventArgs(3,"<font color=green>" +submatch.Groups[1].ToString()  + "="+ submatch.Groups[2].ToString() + "</font>") );
					if ("href" == submatch.Groups[1].ToString().ToLower() ) 
					{
						link = submatch.Groups[2].ToString();
						break;
					}
				}
				// strip off internal links, so we don't index same page over again
				if (link.IndexOf("#") > -1) 
				{
					link = link.Substring(0, link.IndexOf("#"));
				}
				if (link.IndexOf("javascript:") == -1
					&& link.IndexOf("mailto:") == -1
					&& !link.StartsWith("#")
					&& link != String.Empty ) 
				{
					if ( (link.Length > 8) && (link.StartsWith("http://")
						|| link.StartsWith("https://")
						|| link.StartsWith("file://")
						|| link.StartsWith("//")
						|| link.StartsWith(@"\\")) )
					{
						linkExternal.Add (link) ;
						ProgressEvent (this, new ProgressEventArgs(3," X "));
					}
					else if (link.StartsWith("?"))
					{
						// it's possible to have /?query which sends the querystring to the
						// 'default' page in a directory
						linkLocal.Add (pmd.Uri.AbsolutePath + link);
						ProgressEvent (this, new ProgressEventArgs(3," ? "));
					}
					else
					{
						//Uri temp = new Uri(startingUri, link); Response.Write (link);
						linkLocal.Add (link);
						ProgressEvent (this, new ProgressEventArgs(3," I ") );
					}
				} // add each link to a collection
			} // foreach
			pmd.LocalLinks = linkLocal;
			pmd.ExternalLinks = linkExternal;
		} // Parse



		/// <summary>
		///
		/// </summary>
		/// <remarks>
		/// 
		/// </remarks>
		/// <return>Number of words catalogued</return>
		protected int Catalog (HtmlDocument htmldoc)
		{
			string filedesc="";
			long   filesize =0;

			// ### Now remove HTML, convert to array, clean up words and index them ###
			//    string fileContents = StripHtml (htmldoc.All);

			string wordsOnly = StripHtml (htmldoc.All);

			ProgressEvent (this, new ProgressEventArgs(3,"<table><tr><td>" +wordsOnly + "</td></tr></table>"));

			// ### If no META DESC, grab start of file text ###
			if (String.Empty == htmldoc.Description)
			{
				if (wordsOnly.Length > Preferences.SummaryCharacters)
				{
					filedesc = wordsOnly.Substring(0, Preferences.SummaryCharacters);
				}
				else
				{
					filedesc = wordsOnly;
				}
			}
			else
			{ // use the Meta tag
				filedesc = htmldoc.Description;
			}
			// http://authors.aspalliance.com/stevesmith/articles/removewhitespace.asp
			filedesc = Regex.Replace(filedesc, @"\s+", " ").Trim();
        
			// include the Keywords and Description from the Meta tags in the main text to be indexed
			wordsOnly = htmldoc.Keywords + " " + htmldoc.Description + " " + wordsOnly;
			// COMPRESS ALL WHITESPACE into a single space, seperating words
			Regex r = new Regex(@"\s+");            //remove all whitespace
			wordsOnly = r.Replace(wordsOnly, " ");
			string [] wordsOnlyA = wordsOnly.Split(' ');

			File infile = new File (htmldoc.Url
				, htmldoc.Title
				, filedesc
				, DateTime.Now
				, htmldoc.Length) ;

			// ### Loop through words in the file ###
			int i = 0;          // count of words
			string key = "";    // temp variables
			string val = "";
			string pos = "";

			foreach (string word in wordsOnlyA)
			{
				key = word.ToLower();
				if (!GoChecker.IsGoWord (key))
				{	// not a special case, parse like any other word
					//key = word.Trim(' ','?','\"',',','\'',';',':','.','(',')','[',']','%','*','$','-').ToLower(); // this stuff is a bit 'English-language-centric'
					key = System.Text.RegularExpressions.Regex.Replace(key, @"[^a-z0-9,.]", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
				
					if (!IsNumber (ref key)) 
					{	// not a number, so get rid of numeric seperators and catalog as a word
						// TODO: remove inline punctuation, split hyphenated words?
						// http://blogs.msdn.com/ericgu/archive/2006/01/16/513645.aspx
						key = System.Text.RegularExpressions.Regex.Replace(key, "[,.]", "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
						
						// Apply Stemmer (set by preferences)
						key = Stemmer.StemWord (key);
            
						// Apply Stopper (set by preferences)
						key = Stopper.StopWord (key);
					}
				}
				else 
				{
					ProgressEvent (this, new ProgressEventArgs(1,"<font color=blue>found GoWord "+key+"</font>") );
				}
				if (key != String.Empty)
				{
					m_catalog.Add (key, infile, i);
					i++;
				}
			} // foreach

			return i;
		}
		
		/// <summary>
		/// TODO: parse numbers here 
		/// ie remove thousands seperator, currency, etc
		/// and also trim decimal part, so number searches are only on the integer value
		/// </summary>
		/// <param name="word"></param>
		/// <returns></returns>
		private bool IsNumber (ref string word)
		{
			try
			{
				long number = Convert.ToInt64(word); //;int.Parse(word);
				word = number.ToString();
				return (word!=String.Empty);//true;
			}
			catch
			{
				return false;
			}
		}

		/// <summary>
		/// Stripping HTML
		/// http://www.4guysfromrolla.com/webtech/042501-1.shtml
		/// </summary>
		/// <remarks>
		/// Using regex to find tags without a trailing slash
		/// http://concepts.waetech.com/unclosed_tags/index.cfm
		///
		/// http://msdn.microsoft.com/library/en-us/script56/html/js56jsgrpregexpsyntax.asp
		///
		/// Replace html comment tags
		/// http://www.faqts.com/knowledge_base/view.phtml/aid/21761/fid/53
		/// </remarks>
		protected string StripHtml (string Html) 
		{
			//Strips the <script> tags from the Html
			string scriptregex = @"<scr" + @"ipt[^>.]*>[\s\S]*?</sc" + @"ript>";
			System.Text.RegularExpressions.Regex scripts = new System.Text.RegularExpressions.Regex(scriptregex , RegexOptions.IgnoreCase|RegexOptions.Multiline|RegexOptions.ExplicitCapture);
			string scriptless = scripts.Replace(Html, " ");

			//Strips the <style> tags from the Html
			string styleregex = @"<style[^>.]*>[\s\S]*?</style>";
			System.Text.RegularExpressions.Regex styles = new System.Text.RegularExpressions.Regex(styleregex , RegexOptions.IgnoreCase|RegexOptions.Multiline|RegexOptions.ExplicitCapture);
			string styleless = styles.Replace (scriptless, " ");

			//Strips the <!--comment--> tags from the Html	
			//string commentregex = @"<!\-\-.*?\-\->";		// alternate suggestion from antonello franzil 
			string commentregex = @"<!(?:--[\s\S]*?--\s*)?>";
			System.Text.RegularExpressions.Regex comments = new System.Text.RegularExpressions.Regex(commentregex, RegexOptions.IgnoreCase|RegexOptions.Multiline|RegexOptions.ExplicitCapture);
			string commentless = comments.Replace (scriptless, " ");

			//Strips the HTML tags from the Html
			System.Text.RegularExpressions.Regex objRegExp = new System.Text.RegularExpressions.Regex("<(.|\n)+?>", RegexOptions.IgnoreCase);

			//Replace all HTML tag matches with the empty string
			string strOutput = objRegExp.Replace(commentless, " ");

			//Replace all _remaining_ < and > with &lt; and &gt;
			strOutput = strOutput.Replace("<", "&lt;");
			strOutput = strOutput.Replace(">", "&gt;");

			objRegExp = null;
			return strOutput;
		}
	}
	#endregion

	#region HtmlDocument
	/// <summary>
	/// Storage for parsed HTML data returned by ParsedHtmlData();
	/// </summary>
	/// <remarks>
	/// Arbitrary class to encapsulate just the properties we need 
	/// to index Html pages (Title, Meta tags, Keywords, etc).
	/// A 'generic' search engine would probably have a 'generic'
	/// document class, so maybe a future version of Searcharoo 
	/// will too...
	/// </remarks>
	public class HtmlDocument
	{
		public HtmlDocument (Uri location)
		{
			m_Uri = location;
			Url = location.AbsoluteUri.ToString() ;
			LocalLinks = null;
			ExternalLinks = null;
		}
		private Uri m_Uri;
		private String m_contentType;

		/// <summary>
		/// http://www.ietf.org/rfc/rfc2396.txt
		/// </summary>
		public Uri Uri
		{
			get {return m_Uri;}
			set 
			{
				m_Uri = value;
				Url = value.AbsoluteUri.ToString() ;
			}
		}
		/// <summary>
		/// Whether a robot should index the text 
		/// found on this page, or just ignore it
		/// </summary>
		/// <remarks>
		/// Set when page META tags are parsed - no 'set' property
		/// More info:
		/// http://www.robotstxt.org/
		/// </remarks>
		public bool RobotIndexOK
		{
			get {return m_RobotIndexOK;}
			//set {m_RobotIndexOK = value;}
		}
		/// <summary>
		/// Whether a robot should follow any links 
		/// found on this page, or just ignore them
		/// </summary>
		/// <remarks>
		/// Set when page META tags are parsed - no 'set' property
		/// More info:
		/// http://www.robotstxt.org/
		/// </remarks>
		public bool RobotFollowOK
		{
			get {return m_RobotFollowOK;}
			//set {m_RobotFollowOK = value;}
		}
		/// <summary>Raw content of page, as downloaded from the server</summary>
		public string All      = String.Empty;
		/// <summary>Encoding eg. "utf-8", "Shift_JIS", "iso-8859-1", "gb2312", etc</summary>
		public string Encoding = String.Empty;
		/// <summary>MimeType so we know whether to try and parse the contents, eg. "text/html", "text/plain", etc</summary>
		public string MimeType = String.Empty;
		private bool m_RobotIndexOK = true;
		private bool m_RobotFollowOK = true;

		public String ContentType
		{
			get 
			{
				return m_contentType;
			}
			set
			{
				m_contentType = value.ToString();
				string[] contentTypeArray = m_contentType.Split(';');
				// Set MimeType if it's blank
				if (MimeType == String.Empty && contentTypeArray.Length>=1)
				{
					MimeType = contentTypeArray[0];
				}
				// Set Encoding if it's blank
				if (Encoding == String.Empty && contentTypeArray.Length>=2)
				{
					int charsetpos = contentTypeArray[1].IndexOf("charset");
					if (charsetpos > 0) 
					{
						Encoding = contentTypeArray[1].Substring (charsetpos + 8, contentTypeArray[1].Length-charsetpos-8 );
					}
				}
			}
		}
		/// <summary>Sort of obsolete with the Uri field being the main data to use</summary>
		public String Url;
		/// <summary>Html &lt;title&gt; tag</summary>
		public String Title         = String.Empty;
		/// <summary>Html &lt;meta http-equiv='description'&gt; tag</summary>
		public String Description   = String.Empty;
		/// <summary>Html &lt;meta http-equiv='keywords'&gt; tag</summary>
		public String Keywords      = String.Empty;
		/// <summary>Length as reported by the server in the Http headers</summary>
		public Int64 Length;

		public String Html;

		public ArrayList LocalLinks;
		public ArrayList ExternalLinks;

		/// <summary>
		/// Pass in a ROBOTS meta tag found while parsing, 
		/// and set HtmlDocument property/ies appropriately
		/// </summary>
		/// <remarks>
		/// More info:
		/// * Robots Exclusion Protocol *
		/// - for META tags
		/// http://www.robotstxt.org/wc/meta-user.html
		/// - for ROBOTS.TXT in the siteroot
		/// http://www.robotstxt.org/wc/norobots.html
		/// </remarks>
		public void SetRobotDirective (string robotMetaContent) 
		{
			robotMetaContent = robotMetaContent.ToLower();
			if (robotMetaContent.IndexOf("none") >= 0 ) 
			{
				// 'none' means you can't Index or Follow!
				m_RobotIndexOK = false;
				m_RobotFollowOK = false;
			} 
			else 
			{
				if (robotMetaContent.IndexOf("noindex") >=0 ) {m_RobotIndexOK = false;}
				if (robotMetaContent.IndexOf("nofollow") >=0 ) {m_RobotFollowOK = false;}
			}
		}

		/// <summary>
		/// For debugging - output all links found in the page
		/// </summary>
		public override string ToString() 
		{
			string linkstring = "";
			foreach (object link in LocalLinks) 
			{
				linkstring += Convert.ToString (link) + "\r\n";
			}
			return Title + "\r\n" + Description + "\r\n----------------\r\n" + linkstring + "\r\n----------------\r\n" + Html + "\r\n======================\r\n";
		}
	}
	#endregion

	#region Go Words
	/// <summary>
	/// IGoWord
	/// </summary>
	public interface IGoWord
	{
		/// <summary>
		/// Returns true if the word is 'specially marked' for indexing,
		/// bypassing any other Trimming, StopWord or Stemming processing.
		/// </summary>
		/// <remarks>
		/// This method is used to force special strings (possibly including punctuation)
		/// to be indexed and searched without other similar but meaningless cruft clogging
		/// up the catalog, eg. C# html+time 
		/// Note that Go Words CANNOT contain spaces, if they do they'll be recognised as 
		/// two seperate words.
		/// </remarks>
		/// <param name="word">The word to check</param>
		/// <returns>true if 'special', false if the word should be processed normally</returns>
		bool IsGoWord (string word);
	}
	/// <summary>
	/// No-op - if Go Words are disabled this class will be used.
	/// </summary>
	public class NoGoWord : IGoWord
	{
		public bool IsGoWord (string word)
		{
			return false;
		}
	}
	/// <summary>
	/// List of Go words in a switch statement; feel free to
	/// add additional words to this list. 
	/// </summary>
	public class ListGoWord : IGoWord
	{
		public bool IsGoWord (string word)
		{
			switch (word.ToLower())
			{
				case "c#":
				case "vb.net":
				case "asp.net":
					return true;
					break;
			}
			return false;
		}
	}
	/// <summary>
	/// TODO: implement a Go Word method that will read in the word list
	/// from a file. 
	/// http://snowball.tartarus.org/algorithms/english/stop.txt
	/// </summary>
	[Obsolete("well, not obsolete, just not written yet")]
	public class FileGoWord : IGoWord
	{
		/// <summary>
		/// Because this method will use an intelligent list to filter
		/// out stop words, it probably won't need to inherit from the
		/// dodgy implementations above.
		/// </summary>
		public bool IsGoWord (string word)
		{
			throw new NotImplementedException();
		}
	}
	#endregion

	#region Stop Words
	/// <summary>
	/// IStopper 
	/// </summary>
	/// <remarks>
	/// http://libraries.mit.edu/tutorials/general/stopwords.html
	/// http://www.tbray.org/ongoing/When/200x/2003/07/11/Stopwords
	/// 
	/// slightly off-topic, anti-thesaurus or "site-configurable stop-words"
	/// http://www.hastingsresearch.com/net/06-anti-thesaurus.shtml
	/// </remarks>
	public interface IStopper
	{
		/// <summary>
		/// Returns the stemmed form of a word
		/// </summary>
		/// <param name="word">The word to stem. It must be capitalized</param>
		/// <returns>The stemmed word</returns>
		string StopWord (string word);
	}
	public class NoStopping : IStopper
	{
		/// <summary>
		/// Basic 'noop' implementation
		/// </summary>
		/// <param name="word">Word to check against the Stop list</param>
		/// <returns>The input word is always returned unchanged</returns>
		public string StopWord (string word)
		{
			return word;
		}
	}
	/// <summary>
	/// The most basic 'stop word' processor, just ignores
	/// any and ALL words of one or two characters.
	/// </summary>
	/// <remarks>
	/// Examples of words ignored:
	/// a of we in or i to 
	/// </remarks>
	public class ShortStopper : IStopper
	{
		public string StopWord (string word)
		{
			if (word.Length <= 2)
			{
				return String.Empty;
			}
			else
			{
				return word;
			}
		}
	}
	/// <summary>
	/// List of Stop words in a switch statement; feel free to
	/// add additional words to this list. 
	/// Note: it only checks words that are 3 or 4 characters long,
	/// as the base() method already excludes 1 and 2 char words.
	/// </summary>
	/// <remarks>
	/// Examples of words ignored:
	/// the and that you this for but with are have was out not
	/// </remarks>
	public class ListStopper : ShortStopper
	{
		public string StopWord (string word)
		{
			word = base.StopWord (word);
			if ((word!= String.Empty) && (word.Length <= 4))
			{
				switch (word.ToLower())
				{
					case "the":
					case "and":
					case "that":
					case "you":
					case "this":
					case "for":
					case "but":
					case "with":
					case "are":
					case "have":
					case "was":
					case "out":
					case "not":
						return String.Empty;
						break;
				}
			}
			return word;
		}
	}

	/// <summary>
	/// TODO: implement a Stopper that will read in the word list
	/// from a file. 
	/// http://snowball.tartarus.org/algorithms/english/stop.txt
	/// </summary>
	[Obsolete("well, not obsolete, just not written yet")]
	public class FileStopper : IStopper
	{
		/// <summary>
		/// Because this method will use an intelligent list to filter
		/// out stop words, it probably won't need to inherit from the
		/// dodgy implementations above.
		/// </summary>
		public string StopWord (string word)
		{
			throw new NotImplementedException();
		}
	}
	#endregion

	#region Stemming
	/// <summary>
	/// Summary description for Stemming.
	/// </summary>
	public interface IStemming
	{
		/// <summary>
		/// Returns the stemmed form of a word
		/// </summary>
		/// <param name="word">The word to stem. It must be capitalized</param>
		/// <returns>The stemmed word</returns>
		string StemWord (string word);
	}

	public class NoStemming: IStemming
	{
		public string StemWord (string word)
		{
			return word;
		}
	}

	#region Porter Stemmer comments
	/*
	Porter stemmer in CSharp, based on the Java port. The original paper is in

		Porter, 1980, An algorithm for suffix stripping, Program, Vol. 14,
		no. 3, pp 130-137,

	See also http://www.tartarus.org/~martin/PorterStemmer

	History:

	Release 1

	Bug 1 (reported by Gonzalo Parra 16/10/99) fixed as marked below.
	The words 'aed', 'eed', 'oed' leave k at 'a' for step 3, and b[k-1]
	is then out outside the bounds of b.

	Release 2

	Similarly,

	Bug 2 (reported by Steve Dyrdahl 22/2/00) fixed as marked below.
	'ion' by itself leaves j = -1 in the test for 'ion' in step 5, and
	b[j] is then outside the bounds of b.

	Release 3

	Considerably revised 4/9/00 in the light of many helpful suggestions
	from Brian Goetz of Quiotix Corporation (brian@quiotix.com).

	Release 4

	This revision allows the Porter Stemmer Algorithm to be exported via the
	.NET Framework. To facilate its use via .NET, the following commands need to be
	issued to the operating system to register the component so that it can be
	imported into .Net compatible languages, such as Delphi.NET, Visual Basic.NET,
	Visual C++.NET, etc. 

	1. Create a stong name: 		
		sn -k Keyfile.snk  
	2. Compile the C# class, which creates an assembly PorterStemmerAlgorithm.dll
		csc /t:library PorterStemmerAlgorithm.cs
	3. Register the dll with the Windows Registry 
		and so expose the interface to COM Clients via the type library 
		( PorterStemmerAlgorithm.tlb will be created)
		regasm /tlb PorterStemmerAlgorithm.dll
	4. Load the component in the Global Assembly Cache
		gacutil -i PorterStemmerAlgorithm.dll

	Note: You must have the .Net Studio installed.

	Once this process is performed you should be able to import the class 
	via the appropiate mechanism in the language that you are using.

	i.e in Delphi 7 .NET this is simply a matter of selecting: 
		Project | Import Type Libary
	And then selecting Porter stemmer in CSharp Version 1.4"!

	Cheers Leif

	*/
	#endregion
	/// <summary>
	/// By the original author:
	///		Stemmer, implementing the Porter Stemming Algorithm
	/// 
	///		The Stemmer class transforms a word into its root form.  The input
	///		word can be provided a character at time (by calling add()), or at once
	///		by calling one of the various stem(something) methods.
	/// </summary>
	/// <remarks>
	/// source, licence, etc for this class available here:
	/// http://www.tartarus.org/martin/PorterStemmer/
	/// http://www.tartarus.org/martin/PorterStemmer/csharp2.txt
	/// </remarks>
	public class PorterStemmer : IStemming
	{
		private char[] b;
		private int i,     /* offset into b */
			i_end, /* offset to end of stemmed word */
			j, k;
		private static int INC = 200;
		/* unit of size whereby b is increased */
	
		public PorterStemmer() 
		{
			b = new char[INC];
			i = 0;
			i_end = 0;
		}

		/* Implementation of the .NET interface - added as part of realease 4 (Leif) */
		public string StemWord( string s )
		{
			setTerm( s );
			stem();
			return getTerm();
		}

		/*
			SetTerm and GetTerm have been simply added to ease the 
			interface with other lanaguages. They replace the add functions 
			and toString function. This was done because the original functions stored
			all stemmed words (and each time a new woprd was added, the buffer would be
			re-copied each time, making it quite slow). Now, The class interface 
			that is provided simply accepts a term and returns its stem, 
			instead of storing all stemmed words.
			(Leif)
		*/
		void setTerm( string s)
		{
			i = s.Length;
			char[] new_b = new char[i];
			for (int c = 0; c < i; c++)
				new_b[c] = s[c];

			b  = new_b;		

		}

		public string getTerm()
		{
			return new String(b, 0, i_end);
		}

		/* Old interface to the class - left for posterity. However, it is not
			* used when accessing the class via .NET (Leif)*/

		/*
			* Add a character to the word being stemmed.  When you are finished
			* adding characters, you can call stem(void) to stem the word.
			*/
		public void add(char ch) 
		{
			if (i == b.Length) 
			{
				char[] new_b = new char[i+INC];
				for (int c = 0; c < i; c++)
					new_b[c] = b[c];
				b = new_b;
			}
			b[i++] = ch;
		}


		/* Adds wLen characters to the word being stemmed contained in a portion
			* of a char[] array. This is like repeated calls of add(char ch), but
			* faster.
			*/
		public void add(char[] w, int wLen) 
		{
			if (i+wLen >= b.Length) 
			{
				char[] new_b = new char[i+wLen+INC];
				for (int c = 0; c < i; c++)
					new_b[c] = b[c];
				b = new_b;
			}
			for (int c = 0; c < wLen; c++)
				b[i++] = w[c];
		}

		/*
			* After a word has been stemmed, it can be retrieved by toString(),
			* or a reference to the internal buffer can be retrieved by getResultBuffer
			* and getResultLength (which is generally more efficient.)
			*/
		public override string ToString() 
		{
			return new String(b,0,i_end);
		}

		/*
			* Returns the length of the word resulting from the stemming process.
			*/
		public int getResultLength() 
		{
			return i_end;
		}

		/*
			* Returns a reference to a character buffer containing the results of
			* the stemming process.  You also need to consult getResultLength()
			* to determine the length of the result.
			*/
		public char[] getResultBuffer() 
		{
			return b;
		}

		/* cons(i) is true <=> b[i] is a consonant. */
		private bool cons(int i) 
		{
			switch (b[i]) 
			{
				case 'a': case 'e': case 'i': case 'o': case 'u': return false;
				case 'y': return (i==0) ? true : !cons(i-1);
				default: return true;
			}
		}

		/* m() measures the number of consonant sequences between 0 and j. if c is
			a consonant sequence and v a vowel sequence, and <..> indicates arbitrary
			presence,

				<c><v>       gives 0
				<c>vc<v>     gives 1
				<c>vcvc<v>   gives 2
				<c>vcvcvc<v> gives 3
				....
		*/
		private int m() 
		{
			int n = 0;
			int i = 0;
			while(true) 
			{
				if (i > j) return n;
				if (! cons(i)) break; i++;
			}
			i++;
			while(true) 
			{
				while(true) 
				{
					if (i > j) return n;
					if (cons(i)) break;
					i++;
				}
				i++;
				n++;
				while(true) 
				{
					if (i > j) return n;
					if (! cons(i)) break;
					i++;
				}
				i++;
			}
		}

		/* vowelinstem() is true <=> 0,...j contains a vowel */
		private bool vowelinstem() 
		{
			int i;
			for (i = 0; i <= j; i++)
				if (! cons(i))
					return true;
			return false;
		}

		/* doublec(j) is true <=> j,(j-1) contain a double consonant. */
		private bool doublec(int j) 
		{
			if (j < 1)
				return false;
			if (b[j] != b[j-1])
				return false;
			return cons(j);
		}

		/* cvc(i) is true <=> i-2,i-1,i has the form consonant - vowel - consonant
			and also if the second c is not w,x or y. this is used when trying to
			restore an e at the end of a short word. e.g.

				cav(e), lov(e), hop(e), crim(e), but
				snow, box, tray.

		*/
		private bool cvc(int i) 
		{
			if (i < 2 || !cons(i) || cons(i-1) || !cons(i-2))
				return false;
			int ch = b[i];
			if (ch == 'w' || ch == 'x' || ch == 'y')
				return false;
			return true;
		}

		private bool ends(String s) 
		{
			int l = s.Length;
			int o = k-l+1;
			if (o < 0)
				return false;
			char[] sc = s.ToCharArray();
			for (int i = 0; i < l; i++)
				if (b[o+i] != sc[i])
					return false;
			j = k-l;
			return true;
		}

		/* setto(s) sets (j+1),...k to the characters in the string s, readjusting
			k. */
		private void setto(String s) 
		{
			int l = s.Length;
			int o = j+1;
			char[] sc = s.ToCharArray();
			for (int i = 0; i < l; i++)
				b[o+i] = sc[i];
			k = j+l;
		}

		/* r(s) is used further down. */
		private void r(String s) 
		{
			if (m() > 0)
				setto(s);
		}

		/* step1() gets rid of plurals and -ed or -ing. e.g.
				caresses  ->  caress
				ponies    ->  poni
				ties      ->  ti
				caress    ->  caress
				cats      ->  cat

				feed      ->  feed
				agreed    ->  agree
				disabled  ->  disable

				matting   ->  mat
				mating    ->  mate
				meeting   ->  meet
				milling   ->  mill
				messing   ->  mess

				meetings  ->  meet

		*/

		private void step1() 
		{
			if (b[k] == 's') 
			{
				if (ends("sses"))
					k -= 2;
				else if (ends("ies"))
					setto("i");
				else if (b[k-1] != 's')
					k--;
			}
			if (ends("eed")) 
			{
				if (m() > 0)
					k--;
			} 
			else if ((ends("ed") || ends("ing")) && vowelinstem()) 
			{
				k = j;
				if (ends("at"))
					setto("ate");
				else if (ends("bl"))
					setto("ble");
				else if (ends("iz"))
					setto("ize");
				else if (doublec(k)) 
				{
					k--;
					int ch = b[k];
					if (ch == 'l' || ch == 's' || ch == 'z')
						k++;
				}
				else if (m() == 1 && cvc(k)) setto("e");
			}
		}

		/* step2() turns terminal y to i when there is another vowel in the stem. */
		private void step2() 
		{
			if (ends("y") && vowelinstem())
				b[k] = 'i';
		}

		/* step3() maps double suffices to single ones. so -ization ( = -ize plus
			-ation) maps to -ize etc. note that the string before the suffix must give
			m() > 0. */
		private void step3() 
		{
			if (k == 0)
				return;
		
			/* For Bug 1 */
			switch (b[k-1]) 
			{
				case 'a':
					if (ends("ational")) { r("ate"); break; }
					if (ends("tional")) { r("tion"); break; }
					break;
				case 'c':
					if (ends("enci")) { r("ence"); break; }
					if (ends("anci")) { r("ance"); break; }
					break;
				case 'e':
					if (ends("izer")) { r("ize"); break; }
					break;
				case 'l':
					if (ends("bli")) { r("ble"); break; }
					if (ends("alli")) { r("al"); break; }
					if (ends("entli")) { r("ent"); break; }
					if (ends("eli")) { r("e"); break; }
					if (ends("ousli")) { r("ous"); break; }
					break;
				case 'o':
					if (ends("ization")) { r("ize"); break; }
					if (ends("ation")) { r("ate"); break; }
					if (ends("ator")) { r("ate"); break; }
					break;
				case 's':
					if (ends("alism")) { r("al"); break; }
					if (ends("iveness")) { r("ive"); break; }
					if (ends("fulness")) { r("ful"); break; }
					if (ends("ousness")) { r("ous"); break; }
					break;
				case 't':
					if (ends("aliti")) { r("al"); break; }
					if (ends("iviti")) { r("ive"); break; }
					if (ends("biliti")) { r("ble"); break; }
					break;
				case 'g':
					if (ends("logi")) { r("log"); break; }
					break;
				default :
					break;
			}
		}

		/* step4() deals with -ic-, -full, -ness etc. similar strategy to step3. */
		private void step4() 
		{
			switch (b[k]) 
			{
				case 'e':
					if (ends("icate")) { r("ic"); break; }
					if (ends("ative")) { r(""); break; }
					if (ends("alize")) { r("al"); break; }
					break;
				case 'i':
					if (ends("iciti")) { r("ic"); break; }
					break;
				case 'l':
					if (ends("ical")) { r("ic"); break; }
					if (ends("ful")) { r(""); break; }
					break;
				case 's':
					if (ends("ness")) { r(""); break; }
					break;
			}
		}

		/* step5() takes off -ant, -ence etc., in context <c>vcvc<v>. */
		private void step5() 
		{
			if (k == 0)
				return;

			/* for Bug 1 */
			switch ( b[k-1] ) 
			{
				case 'a':
					if (ends("al")) break; return;
				case 'c':
					if (ends("ance")) break;
					if (ends("ence")) break; return;
				case 'e':
					if (ends("er")) break; return;
				case 'i':
					if (ends("ic")) break; return;
				case 'l':
					if (ends("able")) break;
					if (ends("ible")) break; return;
				case 'n':
					if (ends("ant")) break;
					if (ends("ement")) break;
					if (ends("ment")) break;
					/* element etc. not stripped before the m */
					if (ends("ent")) break; return;
				case 'o':
					if (ends("ion") && j >= 0 && (b[j] == 's' || b[j] == 't')) break;
					/* j >= 0 fixes Bug 2 */
					if (ends("ou")) break; return;
					/* takes care of -ous */
				case 's':
					if (ends("ism")) break; return;
				case 't':
					if (ends("ate")) break;
					if (ends("iti")) break; return;
				case 'u':
					if (ends("ous")) break; return;
				case 'v':
					if (ends("ive")) break; return;
				case 'z':
					if (ends("ize")) break; return;
				default:
					return;
			}
			if (m() > 1)
				k = j;
		}

		/* step6() removes a final -e if m() > 1. */
		private void step6() 
		{
			j = k;
		
			if (b[k] == 'e') 
			{
				int a = m();
				if (a > 1 || a == 1 && !cvc(k-1))
					k--;
			}
			if (b[k] == 'l' && doublec(k) && m() > 1)
				k--;
		}

		/* Stem the word placed into the Stemmer buffer through calls to add().
			* Returns true if the stemming process resulted in a word different
			* from the input.  You can retrieve the result with
			* getResultLength()/getResultBuffer() or toString().
			*/
		public void stem() 
		{
			k = i - 1;
			if (k > 1) 
			{
				step1();
				step2();
				step3();
				step4();
				step5();
				step6();
			}
			i_end = k+1;
			i = 0;
		}
	}
	#endregion
}